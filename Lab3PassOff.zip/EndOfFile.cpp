//
// Created by seant on 9/15/2021.
//
#include "EndOfFile.h"

void EndOfFileAutomaton::S0(const std::string& input) {

}
